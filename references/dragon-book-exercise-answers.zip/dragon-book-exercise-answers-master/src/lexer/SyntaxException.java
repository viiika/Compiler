package lexer;

public class SyntaxException extends Exception {

}
